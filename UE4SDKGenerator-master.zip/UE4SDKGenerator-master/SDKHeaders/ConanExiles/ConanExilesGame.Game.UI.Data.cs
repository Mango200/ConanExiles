using ConanExiles;
using ConanExiles.Memory;
using ConanExiles.UnrealClasses;
using ConanExiles.UnrealStructures;
using ConanExilesGame.Script;


namespace ConanExilesGame.Game.UI.Data
{
	/// <summary>
	/// UBP_UIResourceSingleton_C:UUIResourceSingleton
	/// Size: 0x60
	/// Properties: 0
	/// </summary>
	public class UBP_UIResourceSingleton_C:UUIResourceSingleton
	{
		public override int ObjectSize => 96;
	}


}
