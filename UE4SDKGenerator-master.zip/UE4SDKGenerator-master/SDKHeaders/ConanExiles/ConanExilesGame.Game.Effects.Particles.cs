using ConanExiles;
using ConanExiles.Memory;
using ConanExiles.UnrealClasses;
using ConanExiles.UnrealStructures;
using ConanExilesGame.Script;


namespace ConanExilesGame.Game.Effects.Particles
{
	/// <summary>
	/// UBP_CloudParticleSpawner_C:UEgocentricParticleSpawnerComponent
	/// Size: 0x170
	/// Properties: 0
	/// </summary>
	public class UBP_CloudParticleSpawner_C:UEgocentricParticleSpawnerComponent
	{
		public override int ObjectSize => 368;
	}


}
