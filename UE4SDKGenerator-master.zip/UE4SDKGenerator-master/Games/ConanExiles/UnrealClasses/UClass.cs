namespace ConanExiles.UnrealClasses
{
    public class UClass : UStruct
    {
        
    }
}