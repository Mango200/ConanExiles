namespace ConanExiles.UnrealClasses
{
    public class UScriptStruct:UStruct
    {
       
    }
}
