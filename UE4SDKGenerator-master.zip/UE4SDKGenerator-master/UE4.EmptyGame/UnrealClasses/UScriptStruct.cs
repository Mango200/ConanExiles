﻿namespace UE4.EmptyGame.UnrealClasses
{
    public class UScriptStruct:UStruct
    {
       
    }
}
