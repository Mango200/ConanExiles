namespace UE4.EmptyGame.UnrealClasses
{
    public class UClass : UStruct
    {
        
    }
}